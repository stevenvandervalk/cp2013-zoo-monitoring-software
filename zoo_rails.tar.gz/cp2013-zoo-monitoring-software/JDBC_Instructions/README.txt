1. create a Netbeans project
2. right-click on Libraries, and choose "Add JAR/Folder"
3. choose the jar found in this dir (sqlite-jdbc-3.7.2.jar)
4. following the Sample example here: http://code.google.com/p/sqlite-jdbc/
5. Don't forget to update the path to your sql file.

and done... :D
