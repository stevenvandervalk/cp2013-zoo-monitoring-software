# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
WebCp2013Zoo::Application.config.secret_token = '9610e54e1a58768c69e91e663f7bf76ea211c867c341f814f209fcae6a9e80b5f36cb0cdd86981c82aaa4300474798f508ab84ff24e93d08e0678e464fe6d3eb'
