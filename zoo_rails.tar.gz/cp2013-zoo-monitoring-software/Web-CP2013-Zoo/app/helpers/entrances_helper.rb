module EntrancesHelper
end
