require 'test_helper'

class DoorsHelperTest < ActionView::TestCase
end
