require 'test_helper'

class EntrancesHelperTest < ActionView::TestCase
end
